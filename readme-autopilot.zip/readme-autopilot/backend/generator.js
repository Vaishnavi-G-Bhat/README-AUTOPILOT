// Turns a repo profile into README markdown. Uses Claude when a key is set, else a smart template.
const SYSTEM = `You are README Autopilot. Write a README.md that is eye-catching, complete and well balanced: not too short, not bloated.
Rules:
- Markdown only, no raw HTML. Start with an emoji + project title, a one-line tagline, and shields.io badges (language, license, stars).
- Sections in this order when relevant: Overview, Features, Tech Stack (table), Project Structure (tree in a code block with short comments), Getting Started (prerequisites, install, run, env vars table), Usage, Scripts/API, Contributing, License.
- Use tasteful emojis in headings, short paragraphs, and tables. Only state what the files support; never invent features, commands or endpoints.
- If an EXISTING README is given, UPDATE it: keep its voice, manual content, screenshots, links and custom sections; fix anything outdated against the repo files; add missing sections.
- Output ONLY the README markdown, no code fence around it.`;

function describeRepo(p) {
  const files = Object.entries(p.files).map(([k, v]) => `--- ${k} ---\n${v}`).join('\n\n');
  return `Repo: ${p.slug}\nDescription: ${p.description || 'n/a'}\nHomepage: ${p.homepage || 'n/a'}\nTopics: ${p.topics.join(', ') || 'n/a'}\nLicense: ${p.license || 'n/a'}\nStars: ${p.stars}\nLanguages (bytes): ${JSON.stringify(p.languages)}\nDetected stack: ${p.stack.join(', ') || 'n/a'}\n\nFile tree:\n${p.paths.join('\n')}\n\nKey files:\n${files}`;
}

async function viaClaude(p) {
  const user = describeRepo(p) + (p.existingReadme ? `\n\n=== EXISTING README (update this) ===\n${p.existingReadme.slice(0, 12000)}` : '');
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 4000, system: SYSTEM, messages: [{ role: 'user', content: user }] }),
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}`);
  const data = await res.json();
  return data.content.map((c) => c.text || '').join('').replace(/^```(?:markdown|md)?\n/, '').replace(/\n```\s*$/, '').trim();
}

function installBlock(p) {
  const f = p.files, s = p.scripts, clone = [`git clone ${p.url}.git`, `cd ${p.repo}`];
  if (f['package.json']) return [...clone, 'npm install', s.dev ? 'npm run dev' : s.start ? 'npm start' : null].filter(Boolean);
  if (f['requirements.txt'] || f['pyproject.toml']) return [...clone, 'python -m venv .venv && source .venv/bin/activate', f['requirements.txt'] ? 'pip install -r requirements.txt' : 'pip install -e .'];
  if (f['go.mod']) return [...clone, 'go run .'];
  if (f['Cargo.toml']) return [...clone, 'cargo run'];
  if (f['pom.xml']) return [...clone, 'mvn install'];
  return clone;
}

function structure(p) {
  const top = {};
  for (const path of p.paths) { const [a, ...rest] = path.split('/'); top[a] = top[a] || { dir: false }; if (rest.length) top[a].dir = true; }
  const names = Object.keys(top).sort((a, b) => top[b].dir - top[a].dir || a.localeCompare(b)).slice(0, 18);
  return names.map((n, i) => `${i === names.length - 1 ? '└──' : '├──'} ${n}${top[n].dir ? '/' : ''}`).join('\n');
}

function template(p) {
  const langs = Object.keys(p.languages), total = Object.values(p.languages).reduce((a, b) => a + b, 0) || 1;
  const badge = (l, m, c) => `![${l}](https://img.shields.io/badge/${encodeURIComponent(l)}-${encodeURIComponent(m)}-${c})`;
  const badges = [
    langs[0] && badge('language', langs[0], '5b4bff'), p.license && badge('license', p.license, '2ea44f'),
    `![stars](https://img.shields.io/github/stars/${p.slug}?style=flat&color=ffb547)`,
  ].filter(Boolean).join(' ');
  const scripts = Object.entries(p.scripts);
  const docker = p.files['Dockerfile'] ? `\n\n🐳 **Docker:** \`docker build -t ${p.repo.toLowerCase()} . && docker run -p 3000:3000 ${p.repo.toLowerCase()}\`` : '';
  return [
    `# 🚀 ${p.repo}\n\n> ${p.description || 'A project that deserves a great README.'}\n\n${badges}`,
    `## 📖 Overview\n\n${p.description || p.repo} Built with ${p.stack.length ? p.stack.join(', ') : langs.slice(0, 3).join(', ') || 'modern tooling'}${p.homepage ? `. Live: ${p.homepage}` : ''}.`,
    `## 🧰 Tech Stack\n\n| Area | Technology |\n|---|---|\n` + langs.slice(0, 5).map((l) => `| Language | ${l} (${Math.round((p.languages[l] / total) * 100)}%) |`).join('\n') + (p.stack.length ? `\n| Tools & libraries | ${p.stack.join(', ')} |` : ''),
    `## 🗂️ Project Structure\n\n\`\`\`\n${structure(p)}\n\`\`\``,
    `## ⚡ Getting Started\n\n\`\`\`bash\n${installBlock(p).join('\n')}\n\`\`\`${docker}`,
    p.envVars.length ? `## 🔐 Environment Variables\n\nCopy \`.env.example\` to \`.env\` and fill in:\n\n| Variable |\n|---|\n${p.envVars.map((v) => `| \`${v}\` |`).join('\n')}` : null,
    scripts.length ? `## 🧪 Scripts\n\n| Command | What it runs |\n|---|---|\n${scripts.map(([k, v]) => `| \`npm run ${k}\` | \`${v}\` |`).join('\n')}` : null,
    `## 🤝 Contributing\n\nIssues and pull requests are welcome. Fork the repo, create a branch, and open a PR.`,
    p.license ? `## 📄 License\n\nReleased under the ${p.license} license.` : null,
  ].filter(Boolean).join('\n\n');
}

// Keep hand-written sections from the old README that the new one doesn't cover.
function mergeExisting(fresh, old) {
  if (!old) return fresh;
  const heading = (s) => s.replace(/^#+\s*/, '').replace(/[^\w\s]/g, '').trim().toLowerCase();
  const have = new Set(fresh.split(/\n(?=## )/).map((s) => heading(s.split('\n')[0])));
  const extra = old.split(/\n(?=## )/).slice(1).filter((s) => !have.has(heading(s.split('\n')[0])));
  return extra.length ? fresh + '\n\n' + extra.join('\n\n') : fresh;
}

async function generate(profile) {
  let readme, engine = 'template';
  if (process.env.ANTHROPIC_API_KEY) {
    try { readme = await viaClaude(profile); engine = 'claude'; } catch (e) { console.warn('Claude failed, using template:', e.message); }
  }
  if (!readme) readme = mergeExisting(template(profile), profile.existingReadme);
  return { readme, engine };
}

module.exports = { generate };
