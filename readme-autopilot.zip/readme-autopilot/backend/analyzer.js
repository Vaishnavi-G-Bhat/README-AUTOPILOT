// Reads a GitHub repo through the REST API and builds a "profile" the generator can use.
const API = 'https://api.github.com';

function parseRepoUrl(url) {
  const m = String(url).trim().match(/github\.com[/:]([^/\s]+)\/([^/\s#?]+?)(?:\.git)?(?:[/#?].*)?$/i);
  if (!m) throw Object.assign(new Error('Paste a valid GitHub link, e.g. https://github.com/owner/repo'), { status: 400 });
  return { owner: m[1], repo: m[2] };
}

async function gh(path, token, raw = false) {
  const headers = { 'User-Agent': 'readme-autopilot', Accept: raw ? 'application/vnd.github.raw+json' : 'application/vnd.github+json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(API + path, { headers });
  if (res.status === 404) throw Object.assign(new Error('Repository not found. If it is private, add a GitHub token.'), { status: 404 });
  if (res.status === 403 || res.status === 429) throw Object.assign(new Error('GitHub rate limit reached. Add a GitHub token and try again.'), { status: 429 });
  if (!res.ok) throw Object.assign(new Error(`GitHub error ${res.status}`), { status: 502 });
  return raw ? res.text() : res.json();
}

const SKIP = /(^|\/)(node_modules|dist|build|\.git|vendor|__pycache__|\.next|target|coverage)\//;
const NOISE = /(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|poetry\.lock|Cargo\.lock|\.(png|jpe?g|gif|svg|ico|woff2?|ttf|mp4|zip|pdf|min\.js|map)$)/i;
const KEY = /^(package\.json|requirements\.txt|pyproject\.toml|setup\.py|Pipfile|go\.mod|Cargo\.toml|pom\.xml|build\.gradle|composer\.json|Gemfile|Dockerfile|docker-compose\.ya?ml|\.env\.example|Makefile|vite\.config\.\w+|next\.config\.\w+|tsconfig\.json)$/i;
const ENTRY = /^(src\/)?(index|main|app|server|cli)\.(js|ts|jsx|tsx|py|go|rs|java)$|^(backend|server|api)\/(index|main|app|server)\.(js|ts|py)$/i;

const STACK_HINTS = {
  react: 'React', next: 'Next.js', vue: 'Vue', svelte: 'Svelte', express: 'Express', fastify: 'Fastify', nestjs: 'NestJS',
  tailwindcss: 'Tailwind CSS', vite: 'Vite', typescript: 'TypeScript', mongoose: 'MongoDB', prisma: 'Prisma', pg: 'PostgreSQL',
  mysql2: 'MySQL', sqlite3: 'SQLite', 'better-sqlite3': 'SQLite', redis: 'Redis', jest: 'Jest', vitest: 'Vitest',
  flask: 'Flask', django: 'Django', fastapi: 'FastAPI', pytest: 'Pytest', sqlalchemy: 'SQLAlchemy', numpy: 'NumPy', pandas: 'pandas', torch: 'PyTorch', tensorflow: 'TensorFlow',
};

function detectStack(files) {
  const found = new Set();
  const blob = Object.entries(files).filter(([p]) => /package\.json|requirements|pyproject|Pipfile/i.test(p)).map(([, c]) => c.toLowerCase()).join('\n');
  for (const [k, label] of Object.entries(STACK_HINTS)) if (new RegExp(`["'\\s]${k}[\\s"'=<>~^,:]`).test(blob)) found.add(label);
  if (files['Dockerfile'] || files['docker-compose.yml']) found.add('Docker');
  return [...found];
}

async function analyze(url, token) {
  const { owner, repo } = parseRepoUrl(url);
  const meta = await gh(`/repos/${owner}/${repo}`, token);
  const branch = meta.default_branch;
  const [commit, languages] = await Promise.all([gh(`/repos/${owner}/${repo}/commits/${branch}`, token), gh(`/repos/${owner}/${repo}/languages`, token)]);
  const sha = commit.sha;
  const treeRes = await gh(`/repos/${owner}/${repo}/git/trees/${sha}?recursive=1`, token);
  const paths = treeRes.tree.filter((t) => t.type === 'blob' && !SKIP.test(t.path + '/') && !NOISE.test(t.path)).map((t) => t.path);

  const wanted = [
    ...paths.filter((p) => KEY.test(p.split('/').pop()) && p.split('/').length <= 2).slice(0, 10),
    ...paths.filter((p) => ENTRY.test(p)).slice(0, 4),
  ];
  const readmePath = paths.find((p) => /^readme(\.md|\.markdown|\.rst|\.txt)?$/i.test(p));
  const files = {};
  await Promise.all(wanted.map(async (p) => {
    try { files[p] = (await gh(`/repos/${owner}/${repo}/contents/${p.split('/').map(encodeURIComponent).join('/')}?ref=${sha}`, token, true)).slice(0, 3500); } catch { /* skip unreadable */ }
  }));
  let existingReadme = null;
  if (readmePath) try { existingReadme = await gh(`/repos/${owner}/${repo}/contents/${readmePath}?ref=${sha}`, token, true); } catch { /* ignore */ }

  let scripts = {};
  try { scripts = JSON.parse(files['package.json'] || '{}').scripts || {}; } catch { /* ignore */ }
  const envVars = (files['.env.example'] || '').split('\n').map((l) => l.match(/^([A-Z0-9_]+)=/)).filter(Boolean).map((m) => m[1]);

  return {
    owner, repo, slug: `${owner}/${repo}`, url: meta.html_url, description: meta.description, homepage: meta.homepage,
    topics: meta.topics || [], license: meta.license?.spdx_id, stars: meta.stargazers_count, branch, sha, languages,
    paths: paths.slice(0, 250), files, stack: detectStack(files), scripts, envVars, existingReadme, readmePath,
  };
}

module.exports = { analyze, parseRepoUrl };
