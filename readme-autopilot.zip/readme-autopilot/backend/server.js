require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('../database/db');
const { analyze } = require('./analyzer');
const { generate } = require('./generator');

const app = express();
app.use(cors(), express.json({ limit: '200kb' }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

app.post('/api/generate', async (req, res) => {
  try {
    const { repoUrl, token, force } = req.body || {};
    if (!repoUrl) return res.status(400).json({ error: 'Add a repository link first.' });
    const profile = await analyze(repoUrl, token || process.env.GITHUB_TOKEN);
    const cached = db.getRepo(profile.slug);
    if (cached && cached.last_sha === profile.sha && !force)
      return res.json({ status: 'unchanged', slug: profile.slug, sha: profile.sha, readme: cached.last_readme, message: 'No new commits since the last README. Showing the saved version.' });

    const mode = profile.existingReadme ? 'update' : 'create';
    const { readme, engine } = await generate(profile);
    db.saveRun({ slug: profile.slug, url: profile.url, sha: profile.sha, mode, engine, readme });
    res.json({ status: mode === 'update' ? 'updated' : 'created', slug: profile.slug, sha: profile.sha, engine, readme });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

app.get('/api/history', (_req, res) => res.json(db.history()));
app.get('/api/history/:id', (req, res) => { const r = db.getRun(+req.params.id); r ? res.json(r) : res.status(404).json({ error: 'Not found' }); });
app.delete('/api/history/:id', (req, res) => { db.deleteRun(+req.params.id); res.json({ ok: true }); });

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`README Autopilot running at http://localhost:${port}`));
