# 🚀 README Autopilot

Paste a GitHub repository link and get a polished, complete README. If the repo already has one, Autopilot **updates** it to match the latest code and keeps your hand-written sections.

## ✨ Features
- 🔍 Analyzes the file tree, languages, manifests, scripts, Dockerfile and `.env.example`
- 🤖 AI-written READMEs with Claude, or a smart built-in template when no key is set
- ♻️ Update mode: preserves existing content and refreshes what changed
- ⏱️ Skips work when there are no new commits (stored per commit SHA)
- 🕘 History of every run, with live Markdown preview, copy and download

## 🗂️ Structure
```
readme-autopilot/
├── frontend/   index.html, style.css, app.js   (UI + Markdown preview)
├── backend/    server.js, analyzer.js, generator.js   (API, GitHub reader, README writer)
├── database/   db.js, schema.sql   (SQLite: repos + run history)
├── .env.example
└── package.json
```

## ⚡ Getting Started
```bash
npm install
cp .env.example .env      # add ANTHROPIC_API_KEY (and optionally GITHUB_TOKEN)
npm start                 # http://localhost:3000
```
Requires Node 18+.

## 🔌 API
| Method | Route | Purpose |
|---|---|---|
| POST | `/api/generate` | `{ repoUrl, token?, force? }` → README markdown |
| GET | `/api/history` | Recent runs |
| GET | `/api/history/:id` | One saved README |
| DELETE | `/api/history/:id` | Remove a run |

## 📄 License
MIT
