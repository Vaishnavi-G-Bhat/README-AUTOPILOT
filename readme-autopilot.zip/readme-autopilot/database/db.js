const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const db = new Database(path.join(__dirname, 'autopilot.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

module.exports = {
  getRepo: (slug) => db.prepare('SELECT * FROM repos WHERE slug = ?').get(slug),
  saveRun({ slug, url, sha, mode, engine, readme }) {
    db.transaction(() => {
      db.prepare(`INSERT INTO repos (slug, url, last_sha, last_readme) VALUES (?,?,?,?)
        ON CONFLICT(slug) DO UPDATE SET last_sha=excluded.last_sha, last_readme=excluded.last_readme, updated_at=CURRENT_TIMESTAMP`)
        .run(slug, url, sha, readme);
      const repo = db.prepare('SELECT id FROM repos WHERE slug = ?').get(slug);
      db.prepare('INSERT INTO runs (repo_id, sha, mode, engine, readme) VALUES (?,?,?,?,?)')
        .run(repo.id, sha, mode, engine, readme);
    })();
  },
  history: () => db.prepare(`SELECT r.id, p.slug, r.sha, r.mode, r.engine, r.created_at
    FROM runs r JOIN repos p ON p.id = r.repo_id ORDER BY r.id DESC LIMIT 30`).all(),
  getRun: (id) => db.prepare('SELECT r.*, p.slug FROM runs r JOIN repos p ON p.id = r.repo_id WHERE r.id = ?').get(id),
  deleteRun: (id) => db.prepare('DELETE FROM runs WHERE id = ?').run(id),
};
