const $ = (id) => document.getElementById(id);
let current = { readme: '', slug: 'repo' };

function md(src) {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const safe = (u) => (/^(https?:|#|mailto:)/i.test(u) ? u : '#');
  const inline = (s) => esc(s)
    .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (_, a, u) => `<img alt="${a}" src="${/^https?:/i.test(u) ? u : ''}">`)
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, t, u) => `<a href="${safe(u)}" target="_blank" rel="noopener">${t}</a>`)
    .replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  const lines = src.split('\n'); const out = []; let i = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith('```')) { const b = []; i++; while (i < lines.length && !lines[i].startsWith('```')) b.push(lines[i++]); i++; out.push(`<pre><code>${esc(b.join('\n'))}</code></pre>`); continue; }
    const h = l.match(/^(#{1,4})\s+(.*)/); if (h) { out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); i++; continue; }
    if (l.startsWith('|')) {
      const rows = []; while (i < lines.length && lines[i].startsWith('|')) rows.push(lines[i++]);
      const cells = (r) => r.replace(/^\||\|$/g, '').split('|').map((c) => inline(c.trim()));
      const body = rows.filter((_, k) => k !== 1);
      out.push('<table>' + body.map((r, k) => `<tr>${cells(r).map((c) => `<${k ? 'td' : 'th'}>${c}</${k ? 'td' : 'th'}>`).join('')}</tr>`).join('') + '</table>'); continue;
    }
    if (/^\s*[-*]\s+/.test(l)) { const it = []; while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) it.push(`<li>${inline(lines[i++].replace(/^\s*[-*]\s+/, ''))}</li>`); out.push(`<ul>${it.join('')}</ul>`); continue; }
    if (l.startsWith('>')) { out.push(`<blockquote>${inline(l.replace(/^>\s?/, ''))}</blockquote>`); i++; continue; }
    if (!l.trim()) { i++; continue; }
    out.push(`<p>${inline(l)}</p>`); i++;
  }
  return out.join('\n');
}

function show(readme, slug) {
  current = { readme, slug };
  $('preview').innerHTML = md(readme); $('raw').value = readme; $('result').hidden = false;
}
function say(text, kind) { const m = $('msg'); m.textContent = text; m.className = 'msg ' + (kind || ''); m.hidden = !text; }
function step(name) {
  const order = ['fetch', 'analyze', 'write']; $('steps').hidden = !name;
  order.forEach((s, k) => { const li = document.querySelector(`[data-s=${s}]`); li.className = name === 'done' || k < order.indexOf(name) ? 'done' : s === name ? 'on' : ''; });
}

$('form').addEventListener('submit', async (e) => {
  e.preventDefault(); say(''); $('result').hidden = true; $('go').disabled = true;
  step('fetch'); const t1 = setTimeout(() => step('analyze'), 1500), t2 = setTimeout(() => step('write'), 4000);
  try {
    const res = await fetch('/api/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repoUrl: $('url').value, token: $('token').value || undefined, force: $('force').checked }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error);
    step('done'); show(data.readme, data.slug);
    const label = { created: 'README created.', updated: 'Existing README updated to match the repo.', unchanged: data.message }[data.status];
    say(label, 'ok'); loadHistory();
  } catch (err) { step(null); say(err.message, 'err'); }
  finally { clearTimeout(t1); clearTimeout(t2); $('go').disabled = false; }
});

document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('on', x === b));
  $('preview').hidden = b.dataset.t !== 'preview'; $('raw').hidden = b.dataset.t !== 'raw';
}));
$('raw').addEventListener('input', () => { current.readme = $('raw').value; $('preview').innerHTML = md(current.readme); });
$('copy').onclick = async () => { await navigator.clipboard.writeText(current.readme); $('copy').textContent = 'Copied'; setTimeout(() => ($('copy').textContent = 'Copy'), 1500); };
$('dl').onclick = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([current.readme], { type: 'text/markdown' })); a.download = 'README.md'; a.click(); };

async function loadHistory() {
  const rows = await (await fetch('/api/history')).json(); const ul = $('history');
  if (!rows.length) return;
  ul.innerHTML = '';
  rows.forEach((r) => {
    const li = document.createElement('li');
    li.innerHTML = `<button class="open"></button><button class="x" aria-label="Delete run">×</button>`;
    const open = li.querySelector('.open'); open.textContent = r.slug; open.insertAdjacentHTML('beforeend', `<small>${r.mode} · ${new Date(r.created_at + 'Z').toLocaleString()}</small>`);
    open.onclick = async () => { const d = await (await fetch('/api/history/' + r.id)).json(); show(d.readme, d.slug); say(''); step(null); };
    li.querySelector('.x').onclick = async () => { await fetch('/api/history/' + r.id, { method: 'DELETE' }); loadHistory(); };
    ul.appendChild(li);
  });
}
loadHistory();
